api_key = 'V0YCRTMMD4HY8RDU'
url = 'https://www.alphavantage.co/query?'
